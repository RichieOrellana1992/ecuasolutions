<div class="m-t" style="padding-top:25px;">	
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-responsive" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Codigo', (isset($fields['codigo']['language'])? $fields['codigo']['language'] : array())) }}</td>
						<td>{{ $row->codigo}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Nombre', (isset($fields['nombre']['language'])? $fields['nombre']['language'] : array())) }}</td>
						<td>{{ $row->nombre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Bandera', (isset($fields['bandera']['language'])? $fields['bandera']['language'] : array())) }}</td>
						<td>{!! SiteHelpers::formatRows($row->bandera,$fields['bandera'],$row ) !!} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Moneda', (isset($fields['moneda']['language'])? $fields['moneda']['language'] : array())) }}</td>
						<td>{{ $row->moneda}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Moneda Codigo', (isset($fields['moneda_codigo']['language'])? $fields['moneda_codigo']['language'] : array())) }}</td>
						<td>{{ $row->moneda_codigo}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Moneda Simbolo', (isset($fields['moneda_simbolo']['language'])? $fields['moneda_simbolo']['language'] : array())) }}</td>
						<td>{{ $row->moneda_simbolo}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>{{ SiteHelpers::activeLang('Moneda Decimales', (isset($fields['moneda_decimales']['language'])? $fields['moneda_decimales']['language'] : array())) }}</td>
						<td>{{ $row->moneda_decimales}} </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)" class="btn btn-primary"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	